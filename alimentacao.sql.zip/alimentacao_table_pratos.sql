
-- --------------------------------------------------------

--
-- Estrutura da tabela `pratos`
--

CREATE TABLE `pratos` (
  `id_prato` int(11) NOT NULL,
  `nome_prato` varchar(50) NOT NULL,
  `id_restaurante` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pratos`
--

INSERT INTO `pratos` (`id_prato`, `nome_prato`, `id_restaurante`) VALUES
(1, 'Peixe Grelhado', 1),
(2, 'Sushi', 1),
(3, 'Bacalhau', 1),
(4, 'Bife a Cavalo', 2),
(5, 'Burger de Costela', 2),
(6, 'Massa Carbonara', 2),
(7, 'File com Fritas', 3),
(8, 'Costela na Brasa', 3),
(9, 'X-Picanha', 3);
